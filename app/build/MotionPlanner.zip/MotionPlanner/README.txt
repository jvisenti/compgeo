Motion Planner
Rob Visentin and Ellis Ratner

Steps to Run:

1) Open MotionPlanner.app (double click it)

2) File -> Open or cmd+O to open an environment. 

3) Select one of the sample .env files or create your own. 

Environments are specified in MP Markup Language, a simple language created specifically for this project. Take a look at the sample .env files to get a sense of how it works.